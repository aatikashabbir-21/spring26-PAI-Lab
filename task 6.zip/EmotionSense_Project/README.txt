RUN KARNE KA TARIKA

1) VS Code open karo

2) Project folder open karo

3) Terminal open karo

4) Ye command likho:

pip install flask opencv-python

5) Ab project run karo:

python app.py

6) Browser me ye link open karo:

http://127.0.0.1:5000

7) Image upload karo aur result dekho
