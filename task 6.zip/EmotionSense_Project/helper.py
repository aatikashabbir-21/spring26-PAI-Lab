def predict_expression(width_value, height_value):

    calculated = (width_value * height_value) // 100

    if calculated > 300:
        return "Happy Face"

    elif calculated > 180:
        return "Normal Face"

    else:
        return "Calm Face"
