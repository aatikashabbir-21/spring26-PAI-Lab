from flask import Flask, render_template, request
import cv2
import os
from helper import predict_expression

application = Flask(__name__)

SAVE_DIRECTORY = "static/uploads"
application.config["SAVE_DIRECTORY"] = SAVE_DIRECTORY

classifier = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

@application.route("/", methods=["GET", "POST"])
def dashboard():

    output_message = ""
    final_image = ""

    if request.method == "POST":

        incoming_file = request.files["user_image"]

        filename = incoming_file.filename

        location = os.path.join(
            application.config["SAVE_DIRECTORY"],
            filename
        )

        incoming_file.save(location)

        picture = cv2.imread(location)

        black_white = cv2.cvtColor(
            picture,
            cv2.COLOR_BGR2GRAY
        )

        faces_found = classifier.detectMultiScale(
            black_white,
            1.1,
            5
        )

        for left, top, width, height in faces_found:

            mood_result = predict_expression(width, height)

            cv2.rectangle(
                picture,
                (left, top),
                (left + width, top + height),
                (0, 255, 255),
                3
            )

            cv2.putText(
                picture,
                mood_result,
                (left, top - 15),
                cv2.FONT_HERSHEY_COMPLEX,
                0.7,
                (0, 255, 255),
                2
            )

            output_message = mood_result

        cv2.imwrite(location, picture)

        final_image = location

    return render_template(
        "home.html",
        result=output_message,
        image_path=final_image
    )

if __name__ == "__main__":
    application.run(port=5000, debug=True)
