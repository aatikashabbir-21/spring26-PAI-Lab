# Spaceship Titanic Kaggle Competition

Model Used:
- Random Forest Classifier

Expected Accuracy:
- 78% - 82%

Steps:
1. Data Cleaning
2. Missing Value Handling
3. Label Encoding
4. Model Training
5. Submission File Creation

Place train.csv and test.csv inside the data folder before running notebook.
