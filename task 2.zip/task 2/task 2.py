# ================================================
# SPACESHIP TITANIC - Complete Pipeline
# ================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib

# ====================== 1. LOAD DATA ======================
print("Loading datasets...")

# Option A: If you downloaded from Kaggle
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')
submission = pd.read_csv('sample_submission.csv')

print(f"Train shape: {train.shape}")
print(f"Test shape:  {test.shape}")

# ====================== 2. EXPLORATORY DATA ANALYSIS (EDA) ======================
print("\n=== Basic Info ===")
print(train.info())
print("\nMissing Values:")
print(train.isnull().sum())

# Target distribution
plt.figure(figsize=(6,4))
sns.countplot(data=train, x='Transported')
plt.title('Target Distribution (Transported)')
plt.show()

# ====================== 3. FEATURE ENGINEERING ======================
def feature_engineering(df):
    # Split PassengerId
    df['Group'] = df['PassengerId'].apply(lambda x: x.split('_')[0])
    df['GroupSize'] = df['Group'].map(df['Group'].value_counts())
    
    # Split Cabin: deck/num/side
    df['Deck'] = df['Cabin'].apply(lambda x: x.split('/')[0] if pd.notna(x) else np.nan)
    df['Side'] = df['Cabin'].apply(lambda x: x.split('/')[2] if pd.notna(x) else np.nan)
    
    # Total Spending
    spending_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
    df['TotalSpending'] = df[spending_cols].sum(axis=1)
    df['HasSpending'] = (df['TotalSpending'] > 0).astype(int)
    
    # Age Group
    df['AgeGroup'] = pd.cut(df['Age'], bins=[0, 12, 18, 35, 60, 100], 
                           labels=['Child', 'Teen', 'Adult', 'Middle', 'Senior'])
    
    return df

train = feature_engineering(train)
test = feature_engineering(test)

# ====================== 4. PREPROCESSING ======================
def preprocess_data(df, is_train=True):
    # Fill missing values
    df['HomePlanet'] = df['HomePlanet'].fillna(df['HomePlanet'].mode()[0])
    df['CryoSleep'] = df['CryoSleep'].fillna(df['CryoSleep'].mode()[0])
    df['Destination'] = df['Destination'].fillna(df['Destination'].mode()[0])
    df['VIP'] = df['VIP'].fillna(False)
    df['Age'] = df['Age'].fillna(df['Age'].median())
    
    # Spending columns
    spending_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
    for col in spending_cols:
        df[col] = df[col].fillna(0)
    
    df['Deck'] = df['Deck'].fillna('Unknown')
    df['Side'] = df['Side'].fillna('Unknown')
    df['AgeGroup'] = df['AgeGroup'].fillna('Adult')
    
    # Drop unnecessary columns
    drop_cols = ['PassengerId', 'Name', 'Cabin', 'Group']
    df = df.drop(columns=drop_cols, errors='ignore')
    
    return df

train = preprocess_data(train, is_train=True)
test = preprocess_data(test, is_train=False)

# ====================== 5. ENCODING ======================
categorical_cols = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'Deck', 'Side', 'AgeGroup']

for col in categorical_cols:
    le = LabelEncoder()
    train[col] = le.fit_transform(train[col])
    test[col] = le.transform(test[col])

# ====================== 6. SPLIT & SCALE ======================
X = train.drop('Transported', axis=1)
y = train['Transported'].astype(int)

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_val = scaler.transform(X_val)
test_scaled = scaler.transform(test)

# ====================== 7. MODEL TRAINING ======================
print("\nTraining Random Forest Model...")

model = RandomForestClassifier(
    n_estimators=200,
    max_depth=10,
    min_samples_split=5,
    random_state=42,
    n_jobs=-1
)

model.fit(X_train, y_train)

# ====================== 8. EVALUATION ======================
val_pred = model.predict(X_val)
accuracy = accuracy_score(y_val, val_pred)

print(f"\n✅ Validation Accuracy: {accuracy:.4f}")
print("\nClassification Report:")
print(classification_report(y_val, val_pred))

# Feature Importance
importances = pd.DataFrame({
    'Feature': X.columns,
    'Importance': model.feature_importances_
}).sort_values('Importance', ascending=False)

print("\nTop 10 Important Features:")
print(importances.head(10))

# ====================== 9. PREDICTION ON TEST SET ======================
test_pred = model.predict(test_scaled)
submission['Transported'] = test_pred.astype(bool)

submission.to_csv('submission.csv', index=False)
print("\n🎉 Submission file saved as 'submission.csv'")

# ====================== 10. SAVE MODEL ======================
joblib.dump(model, 'spaceship_model.pkl')
joblib.dump(scaler, 'scaler.pkl')
print("Model and scaler saved!")