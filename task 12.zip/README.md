# 🩺 MedQ — Health QnA Bot

A semantic Question-Answering chatbot built with:
- **Hugging Face MiniLM** (`all-MiniLM-L6-v2`) for sentence embeddings
- **FAISS** (Facebook AI Similarity Search) for fast vector retrieval
- **Flask** as the web backend
- A clean dark-themed **HTML/JS** frontend

---

## 📁 Project Structure

```
qna_bot/
├── app.py             ← Flask server (main entry point)
├── build_index.py     ← One-time script to build the FAISS index
├── qa_data.csv        ← Health QnA dataset (50 pairs, 5 categories)
├── requirements.txt   ← Python dependencies
└── templates/
    └── index.html     ← Chat UI
```

---

## 🚀 How to Run (Step-by-Step)

### Step 1 — Create a virtual environment (recommended)

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 2 — Install dependencies

```bash
pip install -r requirements.txt
```

> ⚠️ If you have a CUDA GPU you can replace `faiss-cpu` with `faiss-gpu` for faster indexing.

### Step 3 — Build the FAISS index (only needed ONCE)

```bash
python build_index.py
```

This will:
1. Load `qa_data.csv`
2. Download the MiniLM model (~90 MB, one-time)
3. Encode all questions into vectors
4. Save `embeddings.npy` and `faiss_index.index`

Expected output:
```
Step 1/4 — Loading dataset …
  50 QA pairs loaded.
Step 2/4 — Loading MiniLM model …
Step 3/4 — Encoding questions …
Step 4/4 — Building & saving FAISS index …
✅ Done! Run `python app.py` to start the chatbot server.
```

### Step 4 — Start the Flask server

```bash
python app.py
```

### Step 5 — Open the chatbot in your browser

```
http://127.0.0.1:5000
```

---

## 💬 How It Works

```
User Query
    ↓
clean_text()  →  lowercase + remove symbols
    ↓
MiniLM model  →  384-dim embedding vector
    ↓
FAISS IndexFlatL2  →  find top-5 nearest questions (Euclidean distance)
    ↓
Return matched Q+A pairs with similarity scores
    ↓
Display in browser UI
```

---

## 🗂️ Dataset Categories

| Category        | # of QA Pairs |
|----------------|--------------|
| General Health  | 10           |
| Nutrition       | 10           |
| Mental Health   | 10           |
| First Aid       | 10           |
| Chronic Diseases| 10           |
| **Total**       | **50**       |

---

## ✏️ How to Extend with Your Own Data

1. Open `qa_data.csv`
2. Add your rows following the same format:
   ```
   category,question,answer
   My Topic,Your question here?,Your detailed answer here.
   ```
3. Delete `embeddings.npy` and `faiss_index.index` (if they exist)
4. Re-run `python build_index.py`
5. Start `python app.py`

---

## ❓ Common Issues

| Problem | Solution |
|---------|----------|
| `ModuleNotFoundError: faiss` | Run `pip install faiss-cpu` |
| `Port 5000 already in use` | Change `port=5000` in `app.py` to `5001` |
| Slow first startup | MiniLM model is downloading (~90 MB); wait for it |
| No results returned | Make sure `build_index.py` was run first |
