"""
Run this ONCE before starting the Flask server.
It downloads the MiniLM model, encodes all QA pairs,
and saves the FAISS index to disk.

Usage:
    python build_index.py
"""

import pandas as pd
import numpy as np
import faiss
import re
from sentence_transformers import SentenceTransformer

def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

print("Step 1/4 — Loading dataset …")
qa_df = pd.read_csv('qa_data.csv')
qa_df['Cleaned_Question'] = qa_df['question'].astype(str).apply(clean_text)
qa_df.dropna(subset=['Cleaned_Question'], inplace=True)
qa_df = qa_df[qa_df['Cleaned_Question'].str.strip() != ''].reset_index(drop=True)
print(f"  {len(qa_df)} QA pairs loaded.")

print("Step 2/4 — Loading MiniLM model (downloads ~90 MB on first run) …")
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

print("Step 3/4 — Encoding questions …")
embeddings = model.encode(qa_df['Cleaned_Question'].tolist(), show_progress_bar=True)
embeddings = np.array(embeddings).astype('float32')
np.save('embeddings.npy', embeddings)
print(f"  Embeddings shape: {embeddings.shape}")

print("Step 4/4 — Building & saving FAISS index …")
dim = embeddings.shape[1]
index = faiss.IndexFlatL2(dim)
index.add(embeddings)
faiss.write_index(index, 'faiss_index.index')

print("\n✅ Done! Run `python app.py` to start the chatbot server.")
