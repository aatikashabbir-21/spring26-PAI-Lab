from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
import re
import os

app = Flask(__name__)

# ── Globals ──────────────────────────────────────────────────────────────────
model = None
faiss_index = None
qa_df = None

# ── Text Cleaning ─────────────────────────────────────────────────────────────
def clean_text(text):
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = re.sub(r'[^a-z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# ── Build / Load Index ────────────────────────────────────────────────────────
def setup():
    global model, faiss_index, qa_df

    print("Loading MiniLM model …")
    model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

    csv_path = 'qa_data.csv'
    index_path = 'faiss_index.index'
    emb_path = 'embeddings.npy'

    # Load dataset
    qa_df = pd.read_csv(csv_path)
    qa_df['Cleaned_Question'] = qa_df['question'].astype(str).apply(clean_text)
    qa_df.dropna(subset=['Cleaned_Question'], inplace=True)
    qa_df = qa_df[qa_df['Cleaned_Question'].str.strip() != ''].reset_index(drop=True)

    # Build or load FAISS index
    if os.path.exists(index_path) and os.path.exists(emb_path):
        print("Loading saved index …")
        embeddings = np.load(emb_path)
        faiss_index = faiss.read_index(index_path)
    else:
        print("Building FAISS index (first run – takes ~1 min) …")
        embeddings = model.encode(qa_df['Cleaned_Question'].tolist(), show_progress_bar=True)
        embeddings = np.array(embeddings).astype('float32')
        np.save(emb_path, embeddings)

        dim = embeddings.shape[1]
        faiss_index = faiss.IndexFlatL2(dim)
        faiss_index.add(embeddings)
        faiss.write_index(faiss_index, index_path)

    print(f"Ready! {len(qa_df)} QA pairs indexed.")

# ── Search ────────────────────────────────────────────────────────────────────
def search(query, k=5):
    cleaned = clean_text(query)
    qvec = model.encode([cleaned]).astype('float32')
    distances, indices = faiss_index.search(qvec, k)

    results = []
    for rank, (dist, idx) in enumerate(zip(distances[0], indices[0]), 1):
        row = qa_df.iloc[idx]
        results.append({
            "rank": rank,
            "question": row.get('question', ''),
            "answer": row.get('answer', ''),
            "category": row.get('category', 'General'),
            "distance": round(float(dist), 4),
        })
    return results

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    query = data.get('query', '').strip()
    if not query:
        return jsonify({"error": "Empty query"}), 400
    results = search(query)
    return jsonify({"results": results})

# ── Entry ─────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    setup()
    app.run(debug=False, port=5000)
