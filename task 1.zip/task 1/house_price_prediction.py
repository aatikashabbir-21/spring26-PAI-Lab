"""
═══════════════════════════════════════════════════════════════════════════════
  KAGGLE — House Price Prediction
  Competition : https://www.kaggle.com/competitions/home-data-for-ml-course
═══════════════════════════════════════════════════════════════════════════════

  PIPELINE OVERVIEW
  ─────────────────
  1.  Load & Explore Data           (EDA)
  2.  Handle Missing Values
  3.  Feature Engineering
  4.  Encode Categorical Variables
  5.  Feature Scaling
  6.  Train / Validation Split
  7.  Model Training (5 models)
      - Linear Regression
      - Ridge Regression
      - Random Forest
      - Gradient Boosting
      - XGBoost
  8.  Model Evaluation  (RMSE, MAE, R²)
  9.  Hyperparameter Tuning (best model)
  10. Generate Kaggle Submission CSV

  HOW TO RUN
  ──────────
  1. Download data from the competition page:
       train.csv  →  put in ./data/train.csv
       test.csv   →  put in ./data/test.csv
  2. Install dependencies:
       pip install pandas numpy matplotlib seaborn scikit-learn xgboost
  3. Run:
       python house_price_prediction.py

═══════════════════════════════════════════════════════════════════════════════
"""

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

import xgboost as xgb

warnings.filterwarnings("ignore")
pd.set_option("display.max_columns", 80)
pd.set_option("display.float_format", "{:.2f}".format)

DIVIDER = "\n" + "═" * 70 + "\n"

# ─────────────────────────────────────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────
TRAIN_PATH  = "data/train.csv"
TEST_PATH   = "data/test.csv"
OUTPUT_DIR  = "output"
TARGET_COL  = "SalePrice"
RANDOM_STATE = 42

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs("data",      exist_ok=True)


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 1 — LOAD & EXPLORE DATA
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 1 — LOAD & EXPLORE DATA")
print(DIVIDER)

# ── If files don't exist yet, create small demo datasets so the script runs ──
if not os.path.exists(TRAIN_PATH):
    print("⚠  train.csv not found. Generating a demo dataset …")
    np.random.seed(RANDOM_STATE)
    n = 1460
    demo = pd.DataFrame({
        "Id":            range(1, n + 1),
        "OverallQual":   np.random.randint(1, 11,  n),
        "GrLivArea":     np.random.randint(500, 4000, n),
        "GarageCars":    np.random.randint(0, 4,  n),
        "TotalBsmtSF":   np.random.randint(0, 2000, n),
        "FullBath":      np.random.randint(0, 4, n),
        "YearBuilt":     np.random.randint(1880, 2010, n),
        "YearRemodAdd":  np.random.randint(1950, 2010, n),
        "LotArea":       np.random.randint(2000, 20000, n),
        "Neighborhood":  np.random.choice(["NAmes","CollgCr","OldTown","Edwards","Sawyer"], n),
        "BldgType":      np.random.choice(["1Fam","TwnhsE","Duplex"], n),
        "HouseStyle":    np.random.choice(["1Story","2Story","1.5Fin"], n),
        "ExterQual":     np.random.choice(["Ex","Gd","TA","Fa"], n),
        "KitchenQual":   np.random.choice(["Ex","Gd","TA","Fa"], n),
        "MSZoning":      np.random.choice(["RL","RM","C (all)","FV"], n),
        "CentralAir":    np.random.choice(["Y","N"], n),
        "FireplaceQu":   np.random.choice(["Ex","Gd","TA","Fa", np.nan], n),
        "GarageType":    np.random.choice(["Attchd","Detchd","BuiltIn", np.nan], n),
        "MasVnrArea":    np.where(np.random.rand(n) > 0.4,
                                  np.random.randint(0, 800, n), np.nan),
    })
    # Create a realistic SalePrice based on features
    demo[TARGET_COL] = (
        50000
        + demo["OverallQual"]  * 8000
        + demo["GrLivArea"]    * 50
        + demo["GarageCars"]   * 7000
        + demo["TotalBsmtSF"]  * 30
        + np.random.normal(0, 15000, n)
    ).clip(50000, 750000).astype(int)

    demo.to_csv(TRAIN_PATH, index=False)

    # Test set (no SalePrice)
    test_demo = demo.sample(frac=0.2, random_state=RANDOM_STATE).drop(columns=[TARGET_COL])
    test_demo["Id"] = range(1461, 1461 + len(test_demo))
    test_demo.to_csv(TEST_PATH, index=False)
    print("✔  Demo datasets created.\n")

train_df = pd.read_csv(TRAIN_PATH)
test_df  = pd.read_csv(TEST_PATH)

print(f"► Training set shape  : {train_df.shape}")
print(f"► Test set shape      : {test_df.shape}")
print(f"\n► First 5 rows of training data:")
print(train_df.head())
print(f"\n► Target column statistics:")
print(train_df[TARGET_COL].describe())


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 2 — HANDLE MISSING VALUES
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 2 — HANDLE MISSING VALUES")
print(DIVIDER)

def show_missing(df, label=""):
    missing = df.isnull().sum()
    missing = missing[missing > 0].sort_values(ascending=False)
    if missing.empty:
        print(f"  [{label}] No missing values.")
    else:
        pct = (missing / len(df) * 100).round(2)
        result = pd.DataFrame({"Missing Count": missing, "Missing %": pct})
        print(f"  [{label}] Missing values:\n{result.to_string()}")
    return missing

show_missing(train_df, "TRAIN")
show_missing(test_df,  "TEST")

def fill_missing(df):
    df = df.copy()
    # Numerical: fill with median
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    for col in num_cols:
        if df[col].isnull().sum() > 0:
            df[col].fillna(df[col].median(), inplace=True)

    # Categorical: fill with mode / "None"
    cat_cols = df.select_dtypes(include=["object"]).columns.tolist()
    for col in cat_cols:
        if df[col].isnull().sum() > 0:
            # If > 80 % missing → "None"; else → mode
            if df[col].isnull().mean() > 0.8:
                df[col].fillna("None", inplace=True)
            else:
                df[col].fillna(df[col].mode()[0], inplace=True)
    return df

train_df = fill_missing(train_df)
test_df  = fill_missing(test_df)

print("\n✔  Missing values handled.")
show_missing(train_df, "TRAIN after")
show_missing(test_df,  "TEST after")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 3 — FEATURE ENGINEERING
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 3 — FEATURE ENGINEERING")
print(DIVIDER)

def engineer_features(df):
    df = df.copy()

    # Age of house at time of sale (use 2010 as reference year)
    if "YearBuilt" in df.columns:
        df["HouseAge"]     = 2010 - df["YearBuilt"]
    if "YearRemodAdd" in df.columns:
        df["YearsSinceRemod"] = 2010 - df["YearRemodAdd"]

    # Total square footage
    sf_cols = [c for c in ["TotalBsmtSF", "GrLivArea"] if c in df.columns]
    if sf_cols:
        df["TotalSF"] = df[sf_cols].sum(axis=1)

    # Total bathrooms
    bath_cols = {"FullBath": 1, "HalfBath": 0.5,
                 "BsmtFullBath": 1, "BsmtHalfBath": 0.5}
    present = {k: v for k, v in bath_cols.items() if k in df.columns}
    if present:
        df["TotalBaths"] = sum(df[c] * w for c, w in present.items())

    # Quality × condition interaction
    if "OverallQual" in df.columns and "OverallCond" in df.columns:
        df["QualCond"] = df["OverallQual"] * df["OverallCond"]

    return df

train_df = engineer_features(train_df)
test_df  = engineer_features(test_df)

new_feats = ["HouseAge","YearsSinceRemod","TotalSF","TotalBaths","QualCond"]
existing  = [f for f in new_feats if f in train_df.columns]
print(f"► New features created: {existing}")
print(train_df[existing].describe())


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 4 — ENCODE CATEGORICAL VARIABLES
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 4 — ENCODE CATEGORICAL VARIABLES")
print(DIVIDER)

# Combine train+test for consistent encoding
target  = train_df[TARGET_COL]
train_id = train_df["Id"]
test_id  = test_df["Id"]

train_feats = train_df.drop(columns=[TARGET_COL, "Id"])
test_feats  = test_df.drop(columns=["Id"])

# Align columns
test_feats = test_feats.reindex(columns=train_feats.columns, fill_value=0)

combined = pd.concat([train_feats, test_feats], axis=0, ignore_index=True)

cat_cols = combined.select_dtypes(include=["object"]).columns.tolist()
print(f"► Categorical columns  ({len(cat_cols)}): {cat_cols}")

le = LabelEncoder()
for col in cat_cols:
    combined[col] = le.fit_transform(combined[col].astype(str))

print(f"► All categorical columns encoded with LabelEncoder.")

# Split back
train_enc = combined.iloc[:len(train_feats)].reset_index(drop=True)
test_enc  = combined.iloc[len(train_feats):].reset_index(drop=True)

print(f"► Encoded train shape: {train_enc.shape}")
print(f"► Encoded test shape : {test_enc.shape}")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 5 — FEATURE SCALING
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 5 — FEATURE SCALING")
print(DIVIDER)

scaler       = StandardScaler()
train_scaled = pd.DataFrame(scaler.fit_transform(train_enc),
                             columns=train_enc.columns)
test_scaled  = pd.DataFrame(scaler.transform(test_enc),
                             columns=test_enc.columns)

# Log-transform target (reduces skewness, improves RMSE)
target_log = np.log1p(target)
print(f"► Target skewness  (original)     : {target.skew():.4f}")
print(f"► Target skewness  (log-transformed): {target_log.skew():.4f}")
print("► Features scaled with StandardScaler.")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 6 — TRAIN / VALIDATION SPLIT
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 6 — TRAIN / VALIDATION SPLIT")
print(DIVIDER)

X_train, X_val, y_train, y_val = train_test_split(
    train_scaled, target_log,
    test_size=0.2, random_state=RANDOM_STATE
)
print(f"► X_train : {X_train.shape}  |  y_train : {y_train.shape}")
print(f"► X_val   : {X_val.shape}  |  y_val   : {y_val.shape}")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 7 — MODEL TRAINING
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 7 — MODEL TRAINING (5 Models)")
print(DIVIDER)

models = {
    "Linear Regression":   LinearRegression(),
    "Ridge Regression":    Ridge(alpha=10, random_state=RANDOM_STATE),
    "Random Forest":       RandomForestRegressor(n_estimators=200, max_depth=15,
                                                  random_state=RANDOM_STATE, n_jobs=-1),
    "Gradient Boosting":   GradientBoostingRegressor(n_estimators=300, learning_rate=0.05,
                                                      max_depth=4, random_state=RANDOM_STATE),
    "XGBoost":             xgb.XGBRegressor(n_estimators=300, learning_rate=0.05,
                                             max_depth=5, subsample=0.8,
                                             colsample_bytree=0.8,
                                             random_state=RANDOM_STATE,
                                             verbosity=0),
}

trained = {}
for name, model in models.items():
    print(f"  Training {name} …", end=" ", flush=True)
    model.fit(X_train, y_train)
    trained[name] = model
    print("done ✔")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 8 — MODEL EVALUATION
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 8 — MODEL EVALUATION")
print(DIVIDER)

def evaluate(name, model, X, y_log):
    pred_log   = model.predict(X)
    pred_orig  = np.expm1(pred_log)
    y_orig     = np.expm1(y_log)

    rmse = np.sqrt(mean_squared_error(y_log, pred_log))   # RMSLE (log scale)
    mae  = mean_absolute_error(y_orig, pred_orig)
    r2   = r2_score(y_orig, pred_orig)
    return {"Model": name, "RMSLE": rmse, "MAE": mae, "R²": r2}

results = [evaluate(n, m, X_val, y_val) for n, m in trained.items()]
results_df = pd.DataFrame(results).sort_values("RMSLE")

print(results_df.to_string(index=False))

best_model_name = results_df.iloc[0]["Model"]
best_model      = trained[best_model_name]
print(f"\n► Best Model: {best_model_name}  (lowest RMSLE)")

# Cross-validation on best model
cv_scores = cross_val_score(
    best_model, train_scaled, target_log,
    cv=5, scoring="neg_root_mean_squared_error"
)
print(f"► 5-Fold CV RMSLE: {-cv_scores.mean():.4f} ± {cv_scores.std():.4f}")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 9 — HYPERPARAMETER TUNING (XGBoost / GBM)
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 9 — HYPERPARAMETER TUNING (XGBoost)")
print(DIVIDER)

param_grid = {
    "n_estimators":   [200, 300],
    "max_depth":      [4, 5],
    "learning_rate":  [0.05, 0.1],
}

xgb_tuner = GridSearchCV(
    xgb.XGBRegressor(subsample=0.8, colsample_bytree=0.8,
                     random_state=RANDOM_STATE, verbosity=0),
    param_grid,
    cv=3,
    scoring="neg_root_mean_squared_error",
    n_jobs=-1,
    verbose=0,
)

print("  Running GridSearchCV (this may take a moment) …")
xgb_tuner.fit(X_train, y_train)
best_params = xgb_tuner.best_params_
print(f"  Best params  : {best_params}")
print(f"  Best CV RMSLE: {-xgb_tuner.best_score_:.4f}")

# Retrain with best params on full training data
final_model = xgb.XGBRegressor(
    **best_params,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=RANDOM_STATE,
    verbosity=0,
)
final_model.fit(train_scaled, target_log)
print("✔  Final model trained on full training set.")


# ═════════════════════════════════════════════════════════════════════════════
#  STEP 10 — GENERATE KAGGLE SUBMISSION
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("STEP 10 — GENERATE KAGGLE SUBMISSION CSV")
print(DIVIDER)

preds_log  = final_model.predict(test_scaled)
preds_orig = np.expm1(preds_log)                # reverse log1p transform

submission = pd.DataFrame({
    "Id":        test_id.values,
    "SalePrice": preds_orig.astype(int),
})

submission_path = os.path.join(OUTPUT_DIR, "submission.csv")
submission.to_csv(submission_path, index=False)

print(f"► Submission file saved → {submission_path}")
print(f"► Shape: {submission.shape}")
print(submission.head(10))


# ═════════════════════════════════════════════════════════════════════════════
#  VISUALIZATIONS
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("GENERATING PLOTS …")
print(DIVIDER)

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle("House Price Prediction — EDA & Results", fontsize=15, fontweight="bold")

# 1. SalePrice distribution
axes[0, 0].hist(target, bins=50, color="#4C72B0", edgecolor="white")
axes[0, 0].set_title("SalePrice Distribution (Original)")
axes[0, 0].set_xlabel("SalePrice")
axes[0, 0].set_ylabel("Count")

# 2. Log SalePrice distribution
axes[0, 1].hist(target_log, bins=50, color="#DD8452", edgecolor="white")
axes[0, 1].set_title("SalePrice Distribution (Log-Transformed)")
axes[0, 1].set_xlabel("log(SalePrice)")
axes[0, 1].set_ylabel("Count")

# 3. Model comparison
colors = ["#2196F3" if n == best_model_name else "#90CAF9"
          for n in results_df["Model"]]
axes[1, 0].barh(results_df["Model"], results_df["RMSLE"], color=colors)
axes[1, 0].set_title("Model Comparison (RMSLE — lower is better)")
axes[1, 0].set_xlabel("RMSLE")
axes[1, 0].invert_yaxis()

# 4. Feature importance (XGBoost)
feat_imp = pd.Series(
    final_model.feature_importances_,
    index=train_scaled.columns
).sort_values(ascending=False).head(15)

axes[1, 1].barh(feat_imp.index[::-1], feat_imp.values[::-1], color="#4CAF50")
axes[1, 1].set_title("Top 15 Feature Importances (XGBoost)")
axes[1, 1].set_xlabel("Importance Score")

plt.tight_layout()
plot_path = os.path.join(OUTPUT_DIR, "analysis_plots.png")
plt.savefig(plot_path, dpi=150, bbox_inches="tight")
plt.close()
print(f"► Plots saved → {plot_path}")


# ═════════════════════════════════════════════════════════════════════════════
#  FINAL SUMMARY
# ═════════════════════════════════════════════════════════════════════════════
print(DIVIDER)
print("FINAL SUMMARY")
print(DIVIDER)

val_result = evaluate(best_model_name, final_model, X_val, y_val)
print(f"  Best Model          : {best_model_name}")
print(f"  Best Params         : {best_params}")
print(f"  Validation RMSLE    : {val_result['RMSLE']:.4f}")
print(f"  Validation MAE      : ${val_result['MAE']:,.0f}")
print(f"  Validation R²       : {val_result['R²']:.4f}")
print(f"\n  Submission CSV      : {submission_path}")
print(f"  Analysis Plots      : {plot_path}")
print(f"\n  Upload {submission_path} to:")
print("  https://www.kaggle.com/competitions/home-data-for-ml-course/submissions")
print()
