from flask import Flask
from routes.joke_routes import joke_bp

app = Flask(__name__)

app.register_blueprint(joke_bp)

@app.route("/")
def home():
    return {"message": "Random Joke API is running"}

if __name__ == "__main__":
    app.run(debug=True)