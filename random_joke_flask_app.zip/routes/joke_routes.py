from flask import Blueprint, jsonify
from services.joke_service import fetch_joke

joke_bp = Blueprint('joke', __name__)

@joke_bp.route("/joke", methods=["GET"])
def get_joke():
    joke = fetch_joke()
    return jsonify(joke)