import requests
from config import JOKE_API_URL

def get_random_joke():
    response = requests.get(JOKE_API_URL)

    if response.status_code == 200:
        return response.json()
    else:
        return {"error": "Unable to fetch joke"}