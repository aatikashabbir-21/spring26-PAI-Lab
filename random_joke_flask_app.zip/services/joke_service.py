from utils.api_client import get_random_joke

def fetch_joke():
    joke = get_random_joke()

    if "error" in joke:
        return joke

    return {
        "setup": joke["setup"],
        "punchline": joke["punchline"]
    }