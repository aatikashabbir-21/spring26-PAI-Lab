from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# ─────────────────────────────────────────
#  RESTAURANT KNOWLEDGE BASE
# ─────────────────────────────────────────

MENU = {
    "starters": [
        {"name": "Bruschetta al Pomodoro", "price": 12},
        {"name": "Burrata & Prosciutto",   "price": 18},
        {"name": "Soup of the Day",         "price": 10},
        {"name": "Calamari Fritti",         "price": 15},
    ],
    "pasta": [
        {"name": "Spaghetti Carbonara",   "price": 24},
        {"name": "Tagliatelle al Ragù",   "price": 26},
        {"name": "Truffle Risotto",        "price": 32},
        {"name": "Penne all'Arrabbiata",  "price": 20},
    ],
    "pizza": [
        {"name": "Margherita",        "price": 18},
        {"name": "Diavola (Spicy)",   "price": 22},
        {"name": "Quattro Formaggi",  "price": 24},
        {"name": "Prosciutto e Rucola","price": 26},
    ],
    "mains": [
        {"name": "Bistecca Fiorentina",      "price": 58},
        {"name": "Branzino al Forno",        "price": 44},
        {"name": "Pollo alla Cacciatore",    "price": 34},
        {"name": "Lobster Linguine",         "price": 48},
    ],
    "desserts": [
        {"name": "Tiramisu",     "price": 12},
        {"name": "Panna Cotta",  "price": 10},
        {"name": "Cannoli",      "price": 11},
        {"name": "Gelato (3 scoops)", "price": 9},
    ],
}

HOURS = {
    "Monday":    "12:00 PM – 10:00 PM",
    "Tuesday":   "12:00 PM – 10:00 PM",
    "Wednesday": "12:00 PM – 10:00 PM",
    "Thursday":  "12:00 PM – 10:00 PM",
    "Friday":    "12:00 PM – 11:30 PM",
    "Saturday":  "10:00 AM – 11:30 PM",
    "Sunday":    "10:00 AM – 3:00 PM (Brunch only)",
}

ORDERS = {
    "ORD-1042": {"status": "Preparing", "eta": "20 min"},
    "ORD-1043": {"status": "Out for Delivery", "eta": "10 min"},
    "ORD-1044": {"status": "Delivered", "eta": "—"},
    "ORD-1045": {"status": "Confirmed", "eta": "35 min"},
}


# ─────────────────────────────────────────
#  CHATBOT ENGINE
# ─────────────────────────────────────────

def get_menu_text():
    lines = ["📖 **Full Menu:**\n"]
    emojis = {"starters": "🥗", "pasta": "🍝", "pizza": "🍕", "mains": "🥩", "desserts": "🍮"}
    for section, items in MENU.items():
        lines.append(f"\n{emojis[section]} **{section.capitalize()}**")
        for item in items:
            lines.append(f"  • {item['name']} — ${item['price']}")
    lines.append("\n\n🌿 Allergen info available on request.")
    return "\n".join(lines)


def get_hours_text():
    lines = ["⏰ **Opening Hours:**\n"]
    for day, hours in HOURS.items():
        lines.append(f"  {day[:3]}: {hours}")
    lines.append("\n📍 42 Via Bella, Downtown District")
    lines.append("📞 +1 (555) 789-CIAO")
    return "\n".join(lines)


def chatbot_response(message):
    msg = message.lower().strip()

    # ── Greeting ──
    if any(w in msg for w in ["hello", "hi", "hey", "start", "help", "ciao", "good"]):
        return ("🍽️ **Benvenuti a Bella Cucina!** Welcome!\n\n"
                "I'm your personal restaurant assistant. I can help you with:\n\n"
                "• 📖 **Menu** — view our full menu & prices\n"
                "• 🗓️ **Reserve** — make or check a reservation\n"
                "• 🛵 **Order** — place or track your delivery\n"
                "• ⏰ **Hours** — opening times & location\n"
                "• 🌟 **Specials** — today's chef recommendations\n\n"
                "What can I get started for you?")

    # ── Menu ──
    if any(w in msg for w in ["menu", "food", "eat", "dish", "items", "serve", "cuisine", "price list"]):
        return get_menu_text()

    # ── Specific section ──
    if any(w in msg for w in ["starter", "appetizer", "bruschetta", "calamari", "soup"]):
        items = MENU["starters"]
        lines = ["🥗 **Starters:**\n"]
        for i in items:
            lines.append(f"  • {i['name']} — ${i['price']}")
        return "\n".join(lines)

    if any(w in msg for w in ["pasta", "spaghetti", "risotto", "tagliatelle", "penne", "linguine"]):
        items = MENU["pasta"]
        lines = ["🍝 **Pasta & Risotto:**\n"]
        for i in items:
            lines.append(f"  • {i['name']} — ${i['price']}")
        return "\n".join(lines)

    if any(w in msg for w in ["pizza", "margherita", "diavola", "formaggi"]):
        items = MENU["pizza"]
        lines = ["🍕 **Wood-Fired Pizzas:**\n"]
        for i in items:
            lines.append(f"  • {i['name']} — ${i['price']}")
        return "\n".join(lines)

    if any(w in msg for w in ["dessert", "tiramisu", "panna cotta", "cannoli", "gelato", "sweet"]):
        items = MENU["desserts"]
        lines = ["🍮 **Desserts:**\n"]
        for i in items:
            lines.append(f"  • {i['name']} — ${i['price']}")
        return "\n".join(lines)

    # ── Reservation ──
    if any(w in msg for w in ["reserv", "book", "table", "seat", "dine in"]):
        return ("🗓️ **Make a Reservation:**\n\n"
                "📞 **Call us:** +1 (555) 789-CIAO\n"
                "🌐 **Online:** bellacucina.com/reserve\n"
                "📱 **OpenTable:** Search 'Bella Cucina'\n\n"
                "⏰ **Dining Hours:**\n"
                "  Lunch: Mon–Sun, 12 PM – 3 PM\n"
                "  Dinner: Mon–Thu till 10 PM | Fri–Sat till 11:30 PM\n\n"
                "👥 Groups of 10+? Call ahead for a private room!\n"
                "🎉 Special occasions? We offer custom decor & cake!")

    # ── Order Tracking ──
    if any(w in msg for w in ["track", "order status", "my order", "where is", "delivery status"]):
        return ("🛵 **Track Your Order:**\n\n"
                "Enter your order number (e.g. **ORD-1042**) and I'll check the status!\n\n"
                "Or call us: +1 (555) 789-CIAO\n"
                "You can also track via **DoorDash**, **Uber Eats**, or **Grubhub**.")

    # ── Order number lookup ──
    for order_id in ORDERS:
        if order_id.lower() in msg:
            o = ORDERS[order_id]
            status_emoji = {"Preparing": "👨‍🍳", "Out for Delivery": "🛵",
                            "Delivered": "✅", "Confirmed": "📋"}.get(o["status"], "📦")
            return (f"📦 **Order {order_id} Status:**\n\n"
                    f"  {status_emoji} Status: **{o['status']}**\n"
                    f"  ⏱️ ETA: **{o['eta']}**\n\n"
                    f"Need help? Call +1 (555) 789-CIAO")

    # ── Place an Order ──
    if any(w in msg for w in ["order", "delivery", "takeout", "take away", "pick up"]):
        return ("🛵 **Order Food:**\n\n"
                "**Order Online:** bellacucina.com/order\n"
                "**Phone:** +1 (555) 789-CIAO\n\n"
                "**Delivery via:**\n"
                "  • 🟢 DoorDash\n  • 🟣 Uber Eats\n  • 🔴 Grubhub\n\n"
                "⏱️ Delivery: 30–45 min | Pickup: 15–20 min\n"
                "🆓 **Free delivery** on orders over $50!\n\n"
                "To track an existing order, type your order number (e.g. ORD-1042)")

    # ── Chef Specials ──
    if any(w in msg for w in ["special", "recommend", "best", "popular", "chef", "today", "suggest"]):
        return ("🌟 **Chef's Specials Today:**\n\n"
                "👨‍🍳 Hand-picked by Chef Marco Rossi:\n\n"
                "1. 🦞 **Lobster Linguine** — $48\n"
                "   Fresh Adriatic lobster, cherry tomatoes, basil\n\n"
                "2. 🥩 **Ossobuco alla Milanese** — $52\n"
                "   Slow-braised veal, saffron risotto, gremolata\n\n"
                "3. 🍄 **Truffle Risotto** — $32\n"
                "   Porcini mushrooms, aged Parmigiano, black truffle oil\n\n"
                "🍷 Wine pairing available — ask your server!\n"
                "🎻 Live music every Friday & Saturday evening!")

    # ── Hours & Location ──
    if any(w in msg for w in ["hour", "open", "close", "time", "when", "schedule", "location",
                               "address", "where", "direction", "parking", "sunday", "saturday"]):
        return get_hours_text()

    # ── Price / Cost ──
    if any(w in msg for w in ["price", "cost", "how much", "expensive", "cheap", "budget"]):
        return ("💰 **Price Range:**\n\n"
                "  🥗 Starters: $10 – $18\n"
                "  🍝 Pasta & Risotto: $20 – $32\n"
                "  🍕 Pizza: $18 – $26\n"
                "  🥩 Mains: $34 – $58\n"
                "  🍮 Desserts: $9 – $12\n\n"
                "Average meal per person: ~$35–$55\n"
                "Type **menu** to see the full price list!")

    # ── Vegetarian / Vegan / Allergies ──
    if any(w in msg for w in ["vegan", "vegetarian", "gluten", "allerg", "dairy", "halal", "kosher"]):
        return ("🌿 **Dietary Options:**\n\n"
                "✅ **Vegetarian:** Margherita Pizza, Truffle Risotto, Penne Arrabbiata, all desserts\n"
                "✅ **Vegan:** Penne Arrabbiata (request no cheese), Bruschetta, Soup of the Day\n"
                "✅ **Gluten-Free Pasta:** Available on request (+$3)\n"
                "✅ **Nut-Free options:** Most dishes — confirm with staff\n\n"
                "⚠️ Our kitchen handles nuts, gluten & dairy.\n"
                "Please inform staff of any allergies before ordering!")

    # ── Contact ──
    if any(w in msg for w in ["contact", "phone", "call", "email", "number"]):
        return ("📞 **Contact Bella Cucina:**\n\n"
                "  📱 Phone: +1 (555) 789-CIAO\n"
                "  📧 Email: info@bellacucina.com\n"
                "  🌐 Website: bellacucina.com\n"
                "  📍 42 Via Bella, Downtown District, NY 10001\n\n"
                "  Follow us: @BellaCucinaOfficial")

    # ── Thank you ──
    if any(w in msg for w in ["thank", "thanks", "grazie", "bye", "goodbye", "ciao", "great"]):
        return ("😊 **Grazie mille! Thank you!**\n\n"
                "We look forward to serving you.\n"
                "Buon appetito! 🍝\n\n"
                "Is there anything else I can help you with?")

    # ── Fallback ──
    return ("🤔 I'm not sure about that, but I can help with:\n\n"
            "• 📖 **menu** — view food & prices\n"
            "• 🗓️ **reserve** — book a table\n"
            "• 🛵 **order** — delivery & pickup\n"
            "• 🌟 **specials** — chef recommendations\n"
            "• ⏰ **hours** — opening times\n"
            "• 📞 **contact** — get in touch\n\n"
            "Just type any of those keywords!")


# ─────────────────────────────────────────
#  ROUTES
# ─────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()
    if not user_message:
        return jsonify({"response": "Please type a message!"})
    response = chatbot_response(user_message)
    return jsonify({"response": response})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
